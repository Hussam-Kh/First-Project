IAU Store is a local hosted e-commerce written using HTML, PHP, CSS and JavaScript (It was hosted with XAMPP).<br>
You need to upload the iau_phone_store.sql file to your database at phpmyadmin to try IAU Store.<br><br>
Developed By: @ikema77 @Hussam-Kh @mohammed-algh @FaisalAlfawaz @valisku @Cypher-260 @vinegar97