				</div><!-- all-content-sides -->
			</div> <!-- end of main content -->
			<div class="footer">
				<div class="left_footer">
				<img src="images/logo.png?" alt="Logo" width="100" height="39"/>
				</div>
				<span class="vertical-line"></span>
				<div class="right_footer">&copy; 2022 جميع الحقوق محظفوظة لـ IAU Phone Store<br />
				<img src="images/payment-methods-cards.jpg" alt="Payment Methods" width="240" height="40" /></div>
			</div>
		</div><!-- end of main_container -->
	</body>
</html>